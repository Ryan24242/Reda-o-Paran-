Só executar o script no console da página do Redação Paraná
